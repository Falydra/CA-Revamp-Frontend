import { useEffect, useState } from "react";
import { Link } from "react-scroll";
import { CardWithForm } from "@/Components/CharityCard";
import { BookCharityCard } from "@/Components/BookDonationCard";
import { motion, AnimatePresence } from "framer-motion";
import type { Campaign } from "@/types";
import { apiService } from "@/services/api";
import CampaignCard from "./CampaignCard";
import CampaignCardSkeleton from "./CampaignCardSkeleton";

export default function Charity() {
  const [isMoney, setIsMoney] = useState(true);
  const [isBook, setIsBook] = useState(false);
  const [fundraisers, setFundraisers] = useState<Campaign[]>([]);
  const [productCampaigns, setProductCampaigns] = useState<Campaign[]>([]);
  const [isLoading, setIsLoading] = useState(true);



  const fetchFundraiser = async () => {
    try {
      const response = await apiService.getCampaigns({
        type: "fundraiser",
      });

      if (response.data) {
        console.log(response.data);
        setFundraisers(response.data);
      }
    } catch (err) {
      console.error("Error fetching fundraisers:", err);
    }
  }

  const fetchProductCampaigns = async () => {
    try {
      const response = await apiService.getCampaigns({
        type: "product_donation",
      });

      if (response.data) {
        console.log(response.data);
        setProductCampaigns(response.data);
      }
    } catch (err) {
      console.error("Error fetching product donation campaigns:", err);
    }
  }

  useEffect(() => {
    const fetchData = async () => {
      try {
        await Promise.allSettled([
          fetchFundraiser(),
          fetchProductCampaigns()
        ])
      } finally {
        setIsLoading(false);
      }
    }

    fetchData();
  }, [])

  return (
    <div
      id="charity"
      className="w-full flex flex-col gap-8 justify-center"
    >
      <section className="w-full h-fit flex flex-col items-center justify-start py-16 px-4 relative overflow-hidden">
        <div className="transform w-2/12 top-0 items-center justify-center flex flex-col">
          <div className="relative w-full flex items-center justify-center px-1 py-1 bg-gray-700 border border-gray-600 rounded-full">
            <div
              className={`absolute top-0 left-0 h-full rounded-3xl w-1/2 bg-gradient-to-t from-gray-600 to-transparent shadow-[0_0_10px_3px_rgba(255,255,255,0.3)] transition-transform duration-300 ease-in-out ${isMoney
                ? "translate-x-0 bg-gradient-to-t from-gray-400 z-12 to-transparent"
                : "translate-x-full bg-gradient-to-t from-gray-400 z-12 to-transparent"
                }`}
            />

            <Link
              to="money-charity"
              smooth
              delay={100}
              className="relative w-full py-1 h-9 flex items-center justify-center rounded-full transition-all duration-300 ease-in-out text-sm font-bold text-white cursor-pointer"
              onClick={() => {
                setIsMoney(true);
                setIsBook(false);
              }}
            >
              Charity
            </Link>

            <Link
              to="book-charity"
              smooth
              delay={100}
              className="relative w-full py-1 h-9 flex items-center justify-center rounded-full transition-all duration-300 ease-in-out text-sm font-bold text-white cursor-pointer"
              onClick={() => {
                setIsMoney(false);
                setIsBook(true);
              }}
            >
              Book Donation
            </Link>
          </div>
        </div>

        <div className="relative w-full h-fit flex items-center justify-center">
          <AnimatePresence mode="wait">
            {isMoney && (
              <motion.div
                key="money"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
                className="w-full h-full flex flex-col items-center justify-start py-4"
              >
                <h1 className="text-2xl font-bold text-primary-fg">
                  Berita Terkini
                </h1>

                <CardWithForm
                  campaign={fundraisers[0]} />
              </motion.div>
            )}

            {isBook && (
              <motion.div
                key="book"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
                className="w-full h-full flex flex-col items-center justify-start py-4"
              >
                <h1 className="text-2xl font-bold text-primary-fg ">
                  Berita Terkini
                </h1>
                <div className="w-full flex justify-center">
                  <BookCharityCard campaign={productCampaigns[0]} />
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </section>

      <section className="w-full h-full flex flex-col items-center justify-start px-4 relative overflow-hidden">
        <div className="w-full h-full flex flex-col px-16 gap-4">
          <h2 className="text-xl font-bold">Latest Fundraiser</h2>
          <div className="flex gap-6 py-4 overflow-x-scroll snap-x scrollbar-hide">
            {isLoading ? (
              Array.from({ length: 3 }).map((arr, i) => <CampaignCardSkeleton key={i} />)
            ) : (
              (fundraisers.length > 0 ? (
                fundraisers.slice(0, 3).map((campaign: Campaign) => {
                  return <CampaignCard
                    campaign={campaign}
                    minWidth="80"
                    key={campaign.attributes.slug} />
                })
              ) : (
                <></>
              ))
            )}
          </div>
        </div>
      </section>

      <section className="w-full h-full flex flex-col items-center justify-start px-4 relative overflow-hidden">
        <div className="w-full h-full flex flex-col px-16 gap-4">
          <h2 className="text-xl font-bold">Latest Product Campaigns</h2>
          <div className="flex gap-6 py-4 overflow-x-scroll snap-x scrollbar-hide">
            {isLoading ? (
              Array.from({ length: 3 }).map((arr, i) => <CampaignCardSkeleton key={i} />)
            ) : (
              (productCampaigns.length > 0 ? (
                productCampaigns.map((campaign: Campaign) => {
                  return <CampaignCard
                    campaign={campaign}
                    minWidth="80"
                    key={campaign.attributes.slug} />
                })
              ) : (
                <></>
              ))
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
